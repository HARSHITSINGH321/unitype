const paragraph = [
  "you your he she them their her him me my it its our these this that those who what acceptable all competent satisfying sound which efficient adept honest just even first many one two some like other more new any down and or because but with on than of in to for if by out into about",
  "it is true that bananas have no bones but i like bananas because they are tasty and healthy not because they have no bones i would thus say something false if I said “I like bananas because they have no bones Thats why i like bananas because they have no bones is a statement dding some random keywords ignore if you are reading it",
  "village order shadow age jam banquet original bulb reach mechanism abridge ribbon interface plaster equal market medieval qualified sigh grand braid echo ratio shatter diagram arrange bait frighten movement chin club kick kitchen leg mother dome spread bottom mosquito fat oral delete king lease promote accent umbrella burial know thread",
  "what does make a statement mean make acontinue hold remain occur transpire when now how also not as up here there so very immediately initially additionally nearby extremely greatly time year people day man thing woman work child life world way back i statement is a phrase that means to express an idea or mood without using words, as in Adam made a statement about how he felt about his opponent when he didn't shake their hand.Adding some random keywords, ignore if you are reading it.Adding some random keywords, ignore if you are reading it adding some random keywords ignore if you are reading it",
];

const typingText = document.querySelector(".typing-text p");
inpField = document.querySelector(".wrapper .input-field");
mistakeTag = document.querySelector(".mistake span");
timeTag = document.querySelector(".time span b");
CPMTag = document.querySelector(".cpm span");
WPMTag = document.querySelector(".wpm span");
tryAgainButton= document.querySelector("ul button");

let timer;
let maxTime = 60; //creating a variable
let timeleft = 60; //creating a variable
let characterindex = 0;
let mistakes = 0;
let isTyping = 1;
let wpm = 0;

function randomParagraph() {
  let randomIndex = Math.floor(Math.random() * paragraph.length);
  paragraph[randomIndex].split("").forEach((span) => {
    //here span is the vaurable that stores all the letter one by one because of for each loop
    let spanTag = `<span>${span}</span>`; //dont why it does that
    typingText.innerHTML += spanTag; //adding to the inner written paragraph
  }); //getting random item from the paragraphs array,splitting all character of it, adding each character insider span and then adding this span inside the paragraph tag

  document.addEventListener("keydown", () => inpField.focus()); //focuing input field on key down
  typingText.addEventListener("click", () => inpField.focus()); //or click event
}




function initTyping() {
  const characters = typingText.querySelectorAll("span");//characters will be the list of all the characters in the paragraph
  let typedCharter = inpField.value.split("")[characterindex];
  if (characterindex < characters.length-1 && timeleft > 0) {
    if (isTyping) {
      //once the timer has started it wont be called again on each user input hence eleminating the timer acceleration
      timer = setInterval(initTimer, 1000); //decresing remaining time by one every second by calling initTimer funtion every second
      isTyping = 0;
    }
    //backspace is considered null.
    if (typedCharter == null) {
      characterindex--; //moving backword on pressing backspace
      characters[characterindex].classList.remove("correct", "incorrect"); //removing corrent or incorrect class form classlist if backword key is pressed
    } else {
      if (characters[characterindex].innerText === typedCharter) {
        characters[characterindex].classList.add("correct"); //if typed text is correct class is added to the span
      } else {
        characters[characterindex].classList.add("incorrect");
        mistakes++; //if character didn't matched then mistake is considered
      }
      characterindex++;
    }

    characters.forEach((span) => span.classList.remove("active"));
    characters[characterindex].classList.add("active");
    mistakeTag.innerHTML = mistakes; //storing the mistake value in the mistakeTag
    CPMTag.innerHTML = characterindex - mistakes; //cpm means character permiute
    wpm = Math.round(
      ((characterindex - mistakes) / 5 / (maxTime - timeleft)) * 60
    ); //average word length is taken 5.
    if (wpm < 0 || !wpm || wpm === Infinity || wpm > 250) {
      wpm = 0;
      WPMTag.innerText = wpm;
    } else {
      WPMTag.innerText = wpm;
    }
  }
  else{
    inpField.value="OVER!";
    clearInterval(timer);
  }
}

function initTimer() {
  if (timeleft > 0) {
    timeleft--;
    timeTag.innerText = timeleft;
  } else {
    clearInterval(timer); //this will clears/stops the timer
  }
}

function restart(){//this will add a new paragraph and set variables to defalut, and delete the previous one.
  typingText.innerHTML="";//firstly remove the previous paragraph
  randomParagraph();
  inpField.value="";//cleaning the input field
  clearInterval(timer);
  maxTime = 60; //creating a variable
  timeleft = 60; //creating a variable
  characterindex = 0;
  mistakes = 0;
  isTyping = 1;
  wpm = 0;
  timeTag.innerHTML=maxTime;
  mistakeTag.innerHTML = mistakes; //storing the mistake value in the mistakeTag
  CPMTag.innerHTML = 0; //cpm means character permiute
  WPMTag.innerText = 0;
}




randomParagraph();
inpField.addEventListener("input", initTyping); //what to do when an input is given from keyboard
tryAgainButton.addEventListener("click",restart);



































